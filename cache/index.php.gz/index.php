<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.1//EN" "http://www.w3.org/TR/xhtml11/DTD/xhtml11.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
	<head>
		<title>Home</title>
<meta http-equiv="content-type" content="text/html; charset=utf-8"/>
		<style type="text/css">
/* All versions of IE. Not sent to non-IE UA browsers. */
			#yui-history-iframe {
				position:absolute;
				top:0; left:0;
				width:1px; height:1px;
				visibility:hidden;
			}
		</style>
<!--[if lt IE 8]>
		<style type="text/css">
/* IE < 8, i.e. 7- */
		</style>
<![endif]-->
<!--[if lt IE 7]>
		<style type="text/css">
/* IE < 7, i.e. 6- */
		</style>
<![endif]-->
		<style type="text/css">
div#jema { background:url("images/jema.gif") top left no-repeat; width:24px; height:32px; }
div#kitten { background:url("images/kitten.jpg") top left no-repeat; width:475px; height:360px; }
		</style>
	</head>
	<body>
			<iframe id="yui-history-iframe" src="files/empty.html"></iframe>
	<input id="yui-history-field" type="hidden" />
		<div id="nav">
			<ul>
<li><a href='/jonathankoff.com/home/'>home</a></li><li><a href='/jonathankoff.com/about/'>about</a></li><li><a href='/jonathankoff.com/portfolio/'>portfolio</a></li><li><a href='/jonathankoff.com/contact/'>contact</a></li>			</ul>
		</div>
		<div id="content">
This is the body of the home page.<br/>
<div id='jema'></div>
<div id='kitten'></div>
<img src="/jonathankoff.com/images/kitten.jpg" /><br/>
<img src="/jonathankoff.com/images/kitten.JPG" />
 		</div>
			<script type="text/javascript" src="http://yui.yahooapis.com/2.7.0/build/yahoo-dom-event/yahoo-dom-event.js"></script>
			<script type="text/javascript" src="http://yui.yahooapis.com/2.7.0/build/history/history-min.js"></script>
<script type="text/javascript"><!--

var fileContentArray=[];var fileTitleArray=[];fileContentArray['home']="This is the body of the home page.<br/> <div id='jema'></div> <div id='kitten'></div> <img src='/jonathankoff.com/images/kitten.jpg' /><br/> <img src='/jonathankoff.com/images/kitten.JPG' />  ";fileTitleArray['home']="Home";fileContentArray['about']="This is the body of the about page.  ";fileTitleArray['about']="About Jonathan Koff";fileContentArray['portfolio']="This is the body of the portfolio page.  ";fileTitleArray['portfolio']="Portfolio";fileContentArray['contact']="This is the body of the contact page.  ";fileTitleArray['contact']="Contact Information";function preloader(){for(txt in fileContentArray){var match=fileContentArray[txt].match(/<img src=['"]?([^='"<>\b]*)['"]?\b/ig);imgObj=new Image();for(img in match){var src=match[img].substring(match[img].indexOf("'")+1);imgObj.src=src;}}}
function setIdContent(id,file){if(!fileTitleArray[file])file="home";var obj=document.getElementById(id);if(obj)
obj.innerHTML=fileContentArray[file];document.title=fileTitleArray[file];}
function initNav(){var anchors,i,len,anchor,href,section,currentSection;anchors=document.getElementById("nav").getElementsByTagName("a");for(i=0,len=anchors.length;i<len;i++){anchor=anchors[i];YAHOO.util.Event.addListener(anchor,"click",function(evt){href=this.getAttribute("href");patharr=href.split('/');section=patharr[patharr.length-2]||"home";try{YAHOO.util.History.navigate("page",section);}catch(e){setIdContent("content",section);}
YAHOO.util.Event.preventDefault(evt);});}
currentSection=YAHOO.util.History.getCurrentState("page");setIdContent("content",currentSection);}
var bookmarkedState=YAHOO.util.History.getBookmarkedState("page");var href=""+window.location;var patharr=href.split('/');var section=patharr[patharr.length-2]||"home";var querySection=section;if(!fileContentArray[querySection])
querySection="home";var initialState=bookmarkedState||querySection||"home";YAHOO.util.History.register("page",initialState,function(state){if(state)setIdContent("content",state);});YAHOO.util.History.onReady(function(){initNav();preloader();});try{YAHOO.util.History.initialize("yui-history-field","yui-history-iframe");}catch(e){setIdContent("content","home");}
--></script>	</body>
</html>

