<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.1//EN" "http://www.w3.org/TR/xhtml11/DTD/xhtml11.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
	<head>
		<title>Home</title>
<meta http-equiv="content-type" content="text/html; charset=utf-8"/>
		<style type="text/css">
		</style>
	</head>
	<body>
	<input id="yui-history-field" type="hidden" />
		<div id="nav">
			<ul>
<li><a href='/jonathankoff.com//home/'>home</a></li><li><a href='/jonathankoff.com//about/'>about</a></li><li><a href='/jonathankoff.com//portfolio/'>portfolio</a></li><li><a href='/jonathankoff.com//contact/'>contact</a></li>			</ul>
		</div>
		<div id="content">
This is the body of the home page.<br/>
<img src="/jonathankoff.com/images/kitten.jpg" />
<img src="/jonathankoff.com/images/kitten.JPG" />
		</div>
<script type="text/javascript"><!--

if(typeof YAHOO=="undefined"||!YAHOO){var YAHOO={};}
YAHOO.namespace=function(){var a=arguments,o=null,i,j,d;for(i=0;i<a.length;i=i+1){d=(""+a[i]).split(".");o=YAHOO;for(j=(d[0]=="YAHOO")?1:0;j<d.length;j=j+1){o[d[j]]=o[d[j]]||{};o=o[d[j]];}}
return o;};YAHOO.log=function(msg,cat,src){var l=YAHOO.widget.Logger;if(l&&l.log){return l.log(msg,cat,src);}else{return false;}};YAHOO.register=function(name,mainClass,data){var mods=YAHOO.env.modules,m,v,b,ls,i;if(!mods[name]){mods[name]={versions:[],builds:[]};}
m=mods[name];v=data.version;b=data.build;ls=YAHOO.env.listeners;m.name=name;m.version=v;m.build=b;m.versions.push(v);m.builds.push(b);m.mainClass=mainClass;for(i=0;i<ls.length;i=i+1){ls[i](m);}
if(mainClass){mainClass.VERSION=v;mainClass.BUILD=b;}else{YAHOO.log("mainClass is undefined for module "+name,"warn");}};YAHOO.env=YAHOO.env||{modules:[],listeners:[]};YAHOO.env.getVersion=function(name){return YAHOO.env.modules[name]||null;};YAHOO.env.ua=function(){var o={ie:0,opera:0,gecko:0,webkit:0,mobile:null,air:0,caja:0},ua=navigator.userAgent,m;if((/KHTML/).test(ua)){o.webkit=1;}
m=ua.match(/AppleWebKit\/([^\s]*)/);if(m&&m[1]){o.webkit=parseFloat(m[1]);if(/ Mobile\//.test(ua)){o.mobile="Apple";}else{m=ua.match(/NokiaN[^\/]*/);if(m){o.mobile=m[0];}}
m=ua.match(/AdobeAIR\/([^\s]*)/);if(m){o.air=m[0];}}
if(!o.webkit){m=ua.match(/Opera[\s\/]([^\s]*)/);if(m&&m[1]){o.opera=parseFloat(m[1]);m=ua.match(/Opera Mini[^;]*/);if(m){o.mobile=m[0];}}else{m=ua.match(/MSIE\s([^;]*)/);if(m&&m[1]){o.ie=parseFloat(m[1]);}else{m=ua.match(/Gecko\/([^\s]*)/);if(m){o.gecko=1;m=ua.match(/rv:([^\s\)]*)/);if(m&&m[1]){o.gecko=parseFloat(m[1]);}}}}}
m=ua.match(/Caja\/([^\s]*)/);if(m&&m[1]){o.caja=parseFloat(m[1]);}
return o;}();(function(){YAHOO.namespace("util","widget","example");if("undefined"!==typeof YAHOO_config){var l=YAHOO_config.listener,ls=YAHOO.env.listeners,unique=true,i;if(l){for(i=0;i<ls.length;i=i+1){if(ls[i]==l){unique=false;break;}}
if(unique){ls.push(l);}}}})();YAHOO.lang=YAHOO.lang||{};(function(){var L=YAHOO.lang,ARRAY_TOSTRING='[object Array]',FUNCTION_TOSTRING='[object Function]',OP=Object.prototype,ADD=["toString","valueOf"],OB={isArray:function(o){return OP.toString.apply(o)===ARRAY_TOSTRING;},isBoolean:function(o){return typeof o==='boolean';},isFunction:function(o){return OP.toString.apply(o)===FUNCTION_TOSTRING;},isNull:function(o){return o===null;},isNumber:function(o){return typeof o==='number'&&isFinite(o);},isObject:function(o){return(o&&(typeof o==='object'||L.isFunction(o)))||false;},isString:function(o){return typeof o==='string';},isUndefined:function(o){return typeof o==='undefined';},_IEEnumFix:(YAHOO.env.ua.ie)?function(r,s){var i,fname,f;for(i=0;i<ADD.length;i=i+1){fname=ADD[i];f=s[fname];if(L.isFunction(f)&&f!=OP[fname]){r[fname]=f;}}}:function(){},extend:function(subc,superc,overrides){if(!superc||!subc){throw new Error("extend failed, please check that "+"all dependencies are included.");}
var F=function(){},i;F.prototype=superc.prototype;subc.prototype=new F();subc.prototype.constructor=subc;subc.superclass=superc.prototype;if(superc.prototype.constructor==OP.constructor){superc.prototype.constructor=superc;}
if(overrides){for(i in overrides){if(L.hasOwnProperty(overrides,i)){subc.prototype[i]=overrides[i];}}
L._IEEnumFix(subc.prototype,overrides);}},augmentObject:function(r,s){if(!s||!r){throw new Error("Absorb failed, verify dependencies.");}
var a=arguments,i,p,overrideList=a[2];if(overrideList&&overrideList!==true){for(i=2;i<a.length;i=i+1){r[a[i]]=s[a[i]];}}else{for(p in s){if(overrideList||!(p in r)){r[p]=s[p];}}
L._IEEnumFix(r,s);}},augmentProto:function(r,s){if(!s||!r){throw new Error("Augment failed, verify dependencies.");}
var a=[r.prototype,s.prototype],i;for(i=2;i<arguments.length;i=i+1){a.push(arguments[i]);}
L.augmentObject.apply(this,a);},dump:function(o,d){var i,len,s=[],OBJ="{...}",FUN="f(){...}",COMMA=', ',ARROW=' => ';if(!L.isObject(o)){return o+"";}else if(o instanceof Date||("nodeType"in o&&"tagName"in o)){return o;}else if(L.isFunction(o)){return FUN;}
d=(L.isNumber(d))?d:3;if(L.isArray(o)){s.push("[");for(i=0,len=o.length;i<len;i=i+1){if(L.isObject(o[i])){s.push((d>0)?L.dump(o[i],d-1):OBJ);}else{s.push(o[i]);}
s.push(COMMA);}
if(s.length>1){s.pop();}
s.push("]");}else{s.push("{");for(i in o){if(L.hasOwnProperty(o,i)){s.push(i+ARROW);if(L.isObject(o[i])){s.push((d>0)?L.dump(o[i],d-1):OBJ);}else{s.push(o[i]);}
s.push(COMMA);}}
if(s.length>1){s.pop();}
s.push("}");}
return s.join("");},substitute:function(s,o,f){var i,j,k,key,v,meta,saved=[],token,DUMP='dump',SPACE=' ',LBRACE='{',RBRACE='}',dump;for(;;){i=s.lastIndexOf(LBRACE);if(i<0){break;}
j=s.indexOf(RBRACE,i);if(i+1>=j){break;}
token=s.substring(i+1,j);key=token;meta=null;k=key.indexOf(SPACE);if(k>-1){meta=key.substring(k+1);key=key.substring(0,k);}
v=o[key];if(f){v=f(key,v,meta);}
if(L.isObject(v)){if(L.isArray(v)){v=L.dump(v,parseInt(meta,10));}else{meta=meta||"";dump=meta.indexOf(DUMP);if(dump>-1){meta=meta.substring(4);}
if(v.toString===OP.toString||dump>-1){v=L.dump(v,parseInt(meta,10));}else{v=v.toString();}}}else if(!L.isString(v)&&!L.isNumber(v)){v="~-"+saved.length+"-~";saved[saved.length]=token;}
s=s.substring(0,i)+v+s.substring(j+1);}
for(i=saved.length-1;i>=0;i=i-1){s=s.replace(new RegExp("~-"+i+"-~"),"{"+saved[i]+"}","g");}
return s;},trim:function(s){try{return s.replace(/^\s+|\s+$/g,"");}catch(e){return s;}},merge:function(){var o={},a=arguments,l=a.length,i;for(i=0;i<l;i=i+1){L.augmentObject(o,a[i],true);}
return o;},later:function(when,o,fn,data,periodic){when=when||0;o=o||{};var m=fn,d=data,f,r;if(L.isString(fn)){m=o[fn];}
if(!m){throw new TypeError("method undefined");}
if(!L.isArray(d)){d=[data];}
f=function(){m.apply(o,d);};r=(periodic)?setInterval(f,when):setTimeout(f,when);return{interval:periodic,cancel:function(){if(this.interval){clearInterval(r);}else{clearTimeout(r);}}};},isValue:function(o){return(L.isObject(o)||L.isString(o)||L.isNumber(o)||L.isBoolean(o));}};L.hasOwnProperty=(OP.hasOwnProperty)?function(o,prop){return o&&o.hasOwnProperty(prop);}:function(o,prop){return!L.isUndefined(o[prop])&&o.constructor.prototype[prop]!==o[prop];};OB.augmentObject(L,OB,true);YAHOO.util.Lang=L;L.augment=L.augmentProto;YAHOO.augment=L.augmentProto;YAHOO.extend=L.extend;})();YAHOO.register("yahoo",YAHOO,{version:"2.7.0",build:"1799"});
YAHOO.util.CustomEvent=function(type,context,silent,signature){this.type=type;this.scope=context||window;this.silent=silent;this.signature=signature||YAHOO.util.CustomEvent.LIST;this.subscribers=[];if(!this.silent){}
var onsubscribeType="_YUICEOnSubscribe";if(type!==onsubscribeType){this.subscribeEvent=new YAHOO.util.CustomEvent(onsubscribeType,this,true);}
this.lastError=null;};YAHOO.util.CustomEvent.LIST=0;YAHOO.util.CustomEvent.FLAT=1;YAHOO.util.CustomEvent.prototype={subscribe:function(fn,obj,overrideContext){if(!fn){throw new Error("Invalid callback for subscriber to '"+this.type+"'");}
if(this.subscribeEvent){this.subscribeEvent.fire(fn,obj,overrideContext);}
this.subscribers.push(new YAHOO.util.Subscriber(fn,obj,overrideContext));},unsubscribe:function(fn,obj){if(!fn){return this.unsubscribeAll();}
var found=false;for(var i=0,len=this.subscribers.length;i<len;++i){var s=this.subscribers[i];if(s&&s.contains(fn,obj)){this._delete(i);found=true;}}
return found;},fire:function(){this.lastError=null;var errors=[],len=this.subscribers.length;if(!len&&this.silent){return true;}
var args=[].slice.call(arguments,0),ret=true,i,rebuild=false;if(!this.silent){}
var subs=this.subscribers.slice(),throwErrors=YAHOO.util.Event.throwErrors;for(i=0;i<len;++i){var s=subs[i];if(!s){rebuild=true;}else{if(!this.silent){}
var scope=s.getScope(this.scope);if(this.signature==YAHOO.util.CustomEvent.FLAT){var param=null;if(args.length>0){param=args[0];}
try{ret=s.fn.call(scope,param,s.obj);}catch(e){this.lastError=e;if(throwErrors){throw e;}}}else{try{ret=s.fn.call(scope,this.type,args,s.obj);}catch(ex){this.lastError=ex;if(throwErrors){throw ex;}}}
if(false===ret){if(!this.silent){}
break;}}}
return(ret!==false);},unsubscribeAll:function(){var l=this.subscribers.length,i;for(i=l-1;i>-1;i--){this._delete(i);}
this.subscribers=[];return l;},_delete:function(index){var s=this.subscribers[index];if(s){delete s.fn;delete s.obj;}
this.subscribers.splice(index,1);},toString:function(){return"CustomEvent: "+"'"+this.type+"', "+"context: "+this.scope;}};YAHOO.util.Subscriber=function(fn,obj,overrideContext){this.fn=fn;this.obj=YAHOO.lang.isUndefined(obj)?null:obj;this.overrideContext=overrideContext;};YAHOO.util.Subscriber.prototype.getScope=function(defaultScope){if(this.overrideContext){if(this.overrideContext===true){return this.obj;}else{return this.overrideContext;}}
return defaultScope;};YAHOO.util.Subscriber.prototype.contains=function(fn,obj){if(obj){return(this.fn==fn&&this.obj==obj);}else{return(this.fn==fn);}};YAHOO.util.Subscriber.prototype.toString=function(){return"Subscriber { obj: "+this.obj+", overrideContext: "+(this.overrideContext||"no")+" }";};if(!YAHOO.util.Event){YAHOO.util.Event=function(){var loadComplete=false;var listeners=[];var unloadListeners=[];var legacyEvents=[];var legacyHandlers=[];var retryCount=0;var onAvailStack=[];var legacyMap=[];var counter=0;var webkitKeymap={63232:38,63233:40,63234:37,63235:39,63276:33,63277:34,25:9};var _FOCUS=YAHOO.env.ua.ie?"focusin":"focus";var _BLUR=YAHOO.env.ua.ie?"focusout":"blur";return{POLL_RETRYS:2000,POLL_INTERVAL:20,EL:0,TYPE:1,FN:2,WFN:3,UNLOAD_OBJ:3,ADJ_SCOPE:4,OBJ:5,OVERRIDE:6,lastError:null,isSafari:YAHOO.env.ua.webkit,webkit:YAHOO.env.ua.webkit,isIE:YAHOO.env.ua.ie,_interval:null,_dri:null,DOMReady:false,throwErrors:false,startInterval:function(){if(!this._interval){var self=this;var callback=function(){self._tryPreloadAttach();};this._interval=setInterval(callback,this.POLL_INTERVAL);}},onAvailable:function(id,fn,obj,overrideContext,checkContent){var a=(YAHOO.lang.isString(id))?[id]:id;for(var i=0;i<a.length;i=i+1){onAvailStack.push({id:a[i],fn:fn,obj:obj,overrideContext:overrideContext,checkReady:checkContent});}
retryCount=this.POLL_RETRYS;this.startInterval();},onContentReady:function(id,fn,obj,overrideContext){this.onAvailable(id,fn,obj,overrideContext,true);},onDOMReady:function(fn,obj,overrideContext){if(this.DOMReady){setTimeout(function(){var s=window;if(overrideContext){if(overrideContext===true){s=obj;}else{s=overrideContext;}}
fn.call(s,"DOMReady",[],obj);},0);}else{this.DOMReadyEvent.subscribe(fn,obj,overrideContext);}},_addListener:function(el,sType,fn,obj,overrideContext,bCapture){if(!fn||!fn.call){return false;}
if(this._isValidCollection(el)){var ok=true;for(var i=0,len=el.length;i<len;++i){ok=this.on(el[i],sType,fn,obj,overrideContext)&&ok;}
return ok;}else if(YAHOO.lang.isString(el)){var oEl=this.getEl(el);if(oEl){el=oEl;}else{this.onAvailable(el,function(){YAHOO.util.Event.on(el,sType,fn,obj,overrideContext);});return true;}}
if(!el){return false;}
if("unload"==sType&&obj!==this){unloadListeners[unloadListeners.length]=[el,sType,fn,obj,overrideContext];return true;}
var context=el;if(overrideContext){if(overrideContext===true){context=obj;}else{context=overrideContext;}}
var wrappedFn=function(e){return fn.call(context,YAHOO.util.Event.getEvent(e,el),obj);};var li=[el,sType,fn,wrappedFn,context,obj,overrideContext];var index=listeners.length;listeners[index]=li;if(this.useLegacyEvent(el,sType)){var legacyIndex=this.getLegacyIndex(el,sType);if(legacyIndex==-1||el!=legacyEvents[legacyIndex][0]){legacyIndex=legacyEvents.length;legacyMap[el.id+sType]=legacyIndex;legacyEvents[legacyIndex]=[el,sType,el["on"+sType]];legacyHandlers[legacyIndex]=[];el["on"+sType]=function(e){YAHOO.util.Event.fireLegacyEvent(YAHOO.util.Event.getEvent(e),legacyIndex);};}
legacyHandlers[legacyIndex].push(li);}else{try{this._simpleAdd(el,sType,wrappedFn,bCapture);}catch(ex){this.lastError=ex;this.removeListener(el,sType,fn);return false;}}
return true;},addListener:function(el,sType,fn,obj,overrideContext){return this._addListener(el,sType,fn,obj,overrideContext,false);},addFocusListener:function(el,fn,obj,overrideContext){return this._addListener(el,_FOCUS,fn,obj,overrideContext,true);},removeFocusListener:function(el,fn){return this.removeListener(el,_FOCUS,fn);},addBlurListener:function(el,fn,obj,overrideContext){return this._addListener(el,_BLUR,fn,obj,overrideContext,true);},removeBlurListener:function(el,fn){return this.removeListener(el,_BLUR,fn);},fireLegacyEvent:function(e,legacyIndex){var ok=true,le,lh,li,context,ret;lh=legacyHandlers[legacyIndex].slice();for(var i=0,len=lh.length;i<len;++i){li=lh[i];if(li&&li[this.WFN]){context=li[this.ADJ_SCOPE];ret=li[this.WFN].call(context,e);ok=(ok&&ret);}}
le=legacyEvents[legacyIndex];if(le&&le[2]){le[2](e);}
return ok;},getLegacyIndex:function(el,sType){var key=this.generateId(el)+sType;if(typeof legacyMap[key]=="undefined"){return-1;}else{return legacyMap[key];}},useLegacyEvent:function(el,sType){return(this.webkit&&this.webkit<419&&("click"==sType||"dblclick"==sType));},removeListener:function(el,sType,fn){var i,len,li;if(typeof el=="string"){el=this.getEl(el);}else if(this._isValidCollection(el)){var ok=true;for(i=el.length-1;i>-1;i--){ok=(this.removeListener(el[i],sType,fn)&&ok);}
return ok;}
if(!fn||!fn.call){return this.purgeElement(el,false,sType);}
if("unload"==sType){for(i=unloadListeners.length-1;i>-1;i--){li=unloadListeners[i];if(li&&li[0]==el&&li[1]==sType&&li[2]==fn){unloadListeners.splice(i,1);return true;}}
return false;}
var cacheItem=null;var index=arguments[3];if("undefined"===typeof index){index=this._getCacheIndex(el,sType,fn);}
if(index>=0){cacheItem=listeners[index];}
if(!el||!cacheItem){return false;}
if(this.useLegacyEvent(el,sType)){var legacyIndex=this.getLegacyIndex(el,sType);var llist=legacyHandlers[legacyIndex];if(llist){for(i=0,len=llist.length;i<len;++i){li=llist[i];if(li&&li[this.EL]==el&&li[this.TYPE]==sType&&li[this.FN]==fn){llist.splice(i,1);break;}}}}else{try{this._simpleRemove(el,sType,cacheItem[this.WFN],false);}catch(ex){this.lastError=ex;return false;}}
delete listeners[index][this.WFN];delete listeners[index][this.FN];listeners.splice(index,1);return true;},getTarget:function(ev,resolveTextNode){var t=ev.target||ev.srcElement;return this.resolveTextNode(t);},resolveTextNode:function(n){try{if(n&&3==n.nodeType){return n.parentNode;}}catch(e){}
return n;},getPageX:function(ev){var x=ev.pageX;if(!x&&0!==x){x=ev.clientX||0;if(this.isIE){x+=this._getScrollLeft();}}
return x;},getPageY:function(ev){var y=ev.pageY;if(!y&&0!==y){y=ev.clientY||0;if(this.isIE){y+=this._getScrollTop();}}
return y;},getXY:function(ev){return[this.getPageX(ev),this.getPageY(ev)];},getRelatedTarget:function(ev){var t=ev.relatedTarget;if(!t){if(ev.type=="mouseout"){t=ev.toElement;}else if(ev.type=="mouseover"){t=ev.fromElement;}}
return this.resolveTextNode(t);},getTime:function(ev){if(!ev.time){var t=new Date().getTime();try{ev.time=t;}catch(ex){this.lastError=ex;return t;}}
return ev.time;},stopEvent:function(ev){this.stopPropagation(ev);this.preventDefault(ev);},stopPropagation:function(ev){if(ev.stopPropagation){ev.stopPropagation();}else{ev.cancelBubble=true;}},preventDefault:function(ev){if(ev.preventDefault){ev.preventDefault();}else{ev.returnValue=false;}},getEvent:function(e,boundEl){var ev=e||window.event;if(!ev){var c=this.getEvent.caller;while(c){ev=c.arguments[0];if(ev&&Event==ev.constructor){break;}
c=c.caller;}}
return ev;},getCharCode:function(ev){var code=ev.keyCode||ev.charCode||0;if(YAHOO.env.ua.webkit&&(code in webkitKeymap)){code=webkitKeymap[code];}
return code;},_getCacheIndex:function(el,sType,fn){for(var i=0,l=listeners.length;i<l;i=i+1){var li=listeners[i];if(li&&li[this.FN]==fn&&li[this.EL]==el&&li[this.TYPE]==sType){return i;}}
return-1;},generateId:function(el){var id=el.id;if(!id){id="yuievtautoid-"+counter;++counter;el.id=id;}
return id;},_isValidCollection:function(o){try{return(o&&typeof o!=="string"&&o.length&&!o.tagName&&!o.alert&&typeof o[0]!=="undefined");}catch(ex){return false;}},elCache:{},getEl:function(id){return(typeof id==="string")?document.getElementById(id):id;},clearCache:function(){},DOMReadyEvent:new YAHOO.util.CustomEvent("DOMReady",this),_load:function(e){if(!loadComplete){loadComplete=true;var EU=YAHOO.util.Event;EU._ready();EU._tryPreloadAttach();}},_ready:function(e){var EU=YAHOO.util.Event;if(!EU.DOMReady){EU.DOMReady=true;EU.DOMReadyEvent.fire();EU._simpleRemove(document,"DOMContentLoaded",EU._ready);}},_tryPreloadAttach:function(){if(onAvailStack.length===0){retryCount=0;if(this._interval){clearInterval(this._interval);this._interval=null;}
return;}
if(this.locked){return;}
if(this.isIE){if(!this.DOMReady){this.startInterval();return;}}
this.locked=true;var tryAgain=!loadComplete;if(!tryAgain){tryAgain=(retryCount>0&&onAvailStack.length>0);}
var notAvail=[];var executeItem=function(el,item){var context=el;if(item.overrideContext){if(item.overrideContext===true){context=item.obj;}else{context=item.overrideContext;}}
item.fn.call(context,item.obj);};var i,len,item,el,ready=[];for(i=0,len=onAvailStack.length;i<len;i=i+1){item=onAvailStack[i];if(item){el=this.getEl(item.id);if(el){if(item.checkReady){if(loadComplete||el.nextSibling||!tryAgain){ready.push(item);onAvailStack[i]=null;}}else{executeItem(el,item);onAvailStack[i]=null;}}else{notAvail.push(item);}}}
for(i=0,len=ready.length;i<len;i=i+1){item=ready[i];executeItem(this.getEl(item.id),item);}
retryCount--;if(tryAgain){for(i=onAvailStack.length-1;i>-1;i--){item=onAvailStack[i];if(!item||!item.id){onAvailStack.splice(i,1);}}
this.startInterval();}else{if(this._interval){clearInterval(this._interval);this._interval=null;}}
this.locked=false;},purgeElement:function(el,recurse,sType){var oEl=(YAHOO.lang.isString(el))?this.getEl(el):el;var elListeners=this.getListeners(oEl,sType),i,len;if(elListeners){for(i=elListeners.length-1;i>-1;i--){var l=elListeners[i];this.removeListener(oEl,l.type,l.fn);}}
if(recurse&&oEl&&oEl.childNodes){for(i=0,len=oEl.childNodes.length;i<len;++i){this.purgeElement(oEl.childNodes[i],recurse,sType);}}},getListeners:function(el,sType){var results=[],searchLists;if(!sType){searchLists=[listeners,unloadListeners];}else if(sType==="unload"){searchLists=[unloadListeners];}else{searchLists=[listeners];}
var oEl=(YAHOO.lang.isString(el))?this.getEl(el):el;for(var j=0;j<searchLists.length;j=j+1){var searchList=searchLists[j];if(searchList){for(var i=0,len=searchList.length;i<len;++i){var l=searchList[i];if(l&&l[this.EL]===oEl&&(!sType||sType===l[this.TYPE])){results.push({type:l[this.TYPE],fn:l[this.FN],obj:l[this.OBJ],adjust:l[this.OVERRIDE],scope:l[this.ADJ_SCOPE],index:i});}}}}
return(results.length)?results:null;},_unload:function(e){var EU=YAHOO.util.Event,i,j,l,len,index,ul=unloadListeners.slice(),context;for(i=0,len=unloadListeners.length;i<len;++i){l=ul[i];if(l){context=window;if(l[EU.ADJ_SCOPE]){if(l[EU.ADJ_SCOPE]===true){context=l[EU.UNLOAD_OBJ];}else{context=l[EU.ADJ_SCOPE];}}
l[EU.FN].call(context,EU.getEvent(e,l[EU.EL]),l[EU.UNLOAD_OBJ]);ul[i]=null;}}
l=null;context=null;unloadListeners=null;if(listeners){for(j=listeners.length-1;j>-1;j--){l=listeners[j];if(l){EU.removeListener(l[EU.EL],l[EU.TYPE],l[EU.FN],j);}}
l=null;}
legacyEvents=null;EU._simpleRemove(window,"unload",EU._unload);},_getScrollLeft:function(){return this._getScroll()[1];},_getScrollTop:function(){return this._getScroll()[0];},_getScroll:function(){var dd=document.documentElement,db=document.body;if(dd&&(dd.scrollTop||dd.scrollLeft)){return[dd.scrollTop,dd.scrollLeft];}else if(db){return[db.scrollTop,db.scrollLeft];}else{return[0,0];}},regCE:function(){},_simpleAdd:function(){if(window.addEventListener){return function(el,sType,fn,capture){el.addEventListener(sType,fn,(capture));};}else if(window.attachEvent){return function(el,sType,fn,capture){el.attachEvent("on"+sType,fn);};}else{return function(){};}}(),_simpleRemove:function(){if(window.removeEventListener){return function(el,sType,fn,capture){el.removeEventListener(sType,fn,(capture));};}else if(window.detachEvent){return function(el,sType,fn){el.detachEvent("on"+sType,fn);};}else{return function(){};}}()};}();(function(){var EU=YAHOO.util.Event;EU.on=EU.addListener;EU.onFocus=EU.addFocusListener;EU.onBlur=EU.addBlurListener;if(EU.isIE){YAHOO.util.Event.onDOMReady(YAHOO.util.Event._tryPreloadAttach,YAHOO.util.Event,true);var n=document.createElement('p');EU._dri=setInterval(function(){try{n.doScroll('left');clearInterval(EU._dri);EU._dri=null;EU._ready();n=null;}catch(ex){}},EU.POLL_INTERVAL);}else if(EU.webkit&&EU.webkit<525){EU._dri=setInterval(function(){var rs=document.readyState;if("loaded"==rs||"complete"==rs){clearInterval(EU._dri);EU._dri=null;EU._ready();}},EU.POLL_INTERVAL);}else{EU._simpleAdd(document,"DOMContentLoaded",EU._ready);}
EU._simpleAdd(window,"load",EU._load);EU._simpleAdd(window,"unload",EU._unload);EU._tryPreloadAttach();})();}
YAHOO.util.EventProvider=function(){};YAHOO.util.EventProvider.prototype={__yui_events:null,__yui_subscribers:null,subscribe:function(p_type,p_fn,p_obj,overrideContext){this.__yui_events=this.__yui_events||{};var ce=this.__yui_events[p_type];if(ce){ce.subscribe(p_fn,p_obj,overrideContext);}else{this.__yui_subscribers=this.__yui_subscribers||{};var subs=this.__yui_subscribers;if(!subs[p_type]){subs[p_type]=[];}
subs[p_type].push({fn:p_fn,obj:p_obj,overrideContext:overrideContext});}},unsubscribe:function(p_type,p_fn,p_obj){this.__yui_events=this.__yui_events||{};var evts=this.__yui_events;if(p_type){var ce=evts[p_type];if(ce){return ce.unsubscribe(p_fn,p_obj);}}else{var ret=true;for(var i in evts){if(YAHOO.lang.hasOwnProperty(evts,i)){ret=ret&&evts[i].unsubscribe(p_fn,p_obj);}}
return ret;}
return false;},unsubscribeAll:function(p_type){return this.unsubscribe(p_type);},createEvent:function(p_type,p_config){this.__yui_events=this.__yui_events||{};var opts=p_config||{};var events=this.__yui_events;if(events[p_type]){}else{var scope=opts.scope||this;var silent=(opts.silent);var ce=new YAHOO.util.CustomEvent(p_type,scope,silent,YAHOO.util.CustomEvent.FLAT);events[p_type]=ce;if(opts.onSubscribeCallback){ce.subscribeEvent.subscribe(opts.onSubscribeCallback);}
this.__yui_subscribers=this.__yui_subscribers||{};var qs=this.__yui_subscribers[p_type];if(qs){for(var i=0;i<qs.length;++i){ce.subscribe(qs[i].fn,qs[i].obj,qs[i].overrideContext);}}}
return events[p_type];},fireEvent:function(p_type,arg1,arg2,etc){this.__yui_events=this.__yui_events||{};var ce=this.__yui_events[p_type];if(!ce){return null;}
var args=[];for(var i=1;i<arguments.length;++i){args.push(arguments[i]);}
return ce.fire.apply(ce,args);},hasEvent:function(type){if(this.__yui_events){if(this.__yui_events[type]){return true;}}
return false;}};(function(){var Event=YAHOO.util.Event,Lang=YAHOO.lang;YAHOO.util.KeyListener=function(attachTo,keyData,handler,event){if(!attachTo){}else if(!keyData){}else if(!handler){}
if(!event){event=YAHOO.util.KeyListener.KEYDOWN;}
var keyEvent=new YAHOO.util.CustomEvent("keyPressed");this.enabledEvent=new YAHOO.util.CustomEvent("enabled");this.disabledEvent=new YAHOO.util.CustomEvent("disabled");if(Lang.isString(attachTo)){attachTo=document.getElementById(attachTo);}
if(Lang.isFunction(handler)){keyEvent.subscribe(handler);}else{keyEvent.subscribe(handler.fn,handler.scope,handler.correctScope);}
function handleKeyPress(e,obj){if(!keyData.shift){keyData.shift=false;}
if(!keyData.alt){keyData.alt=false;}
if(!keyData.ctrl){keyData.ctrl=false;}
if(e.shiftKey==keyData.shift&&e.altKey==keyData.alt&&e.ctrlKey==keyData.ctrl){var dataItem,keys=keyData.keys,key;if(YAHOO.lang.isArray(keys)){for(var i=0;i<keys.length;i++){dataItem=keys[i];key=Event.getCharCode(e);if(dataItem==key){keyEvent.fire(key,e);break;}}}else{key=Event.getCharCode(e);if(keys==key){keyEvent.fire(key,e);}}}}
this.enable=function(){if(!this.enabled){Event.on(attachTo,event,handleKeyPress);this.enabledEvent.fire(keyData);}
this.enabled=true;};this.disable=function(){if(this.enabled){Event.removeListener(attachTo,event,handleKeyPress);this.disabledEvent.fire(keyData);}
this.enabled=false;};this.toString=function(){return"KeyListener ["+keyData.keys+"] "+attachTo.tagName+
(attachTo.id?"["+attachTo.id+"]":"");};};var KeyListener=YAHOO.util.KeyListener;KeyListener.KEYDOWN="keydown";KeyListener.KEYUP="keyup";KeyListener.KEY={ALT:18,BACK_SPACE:8,CAPS_LOCK:20,CONTROL:17,DELETE:46,DOWN:40,END:35,ENTER:13,ESCAPE:27,HOME:36,LEFT:37,META:224,NUM_LOCK:144,PAGE_DOWN:34,PAGE_UP:33,PAUSE:19,PRINTSCREEN:44,RIGHT:39,SCROLL_LOCK:145,SHIFT:16,SPACE:32,TAB:9,UP:38};})();YAHOO.register("event",YAHOO.util.Event,{version:"2.7.0",build:"1799"});
YAHOO.util.History=(function(){var _histFrame=null;var _stateField=null;var _initialized=false;var _modules=[];var _fqstates=[];function _getHash(){var i,href;href=top.location.href;i=href.indexOf("#");return i>=0?("page="+href.substr(i+1)):null;}
function _storeStates(){var moduleName,moduleObj,initialStates=[],currentStates=[];for(moduleName in _modules){if(YAHOO.lang.hasOwnProperty(_modules,moduleName)){moduleObj=_modules[moduleName];initialStates.push(moduleName+"="+moduleObj.initialState);currentStates.push(moduleName+"="+moduleObj.currentState);}}
_stateField.value=initialStates.join("&")+"|"+currentStates.join("&");if(YAHOO.env.ua.webkit){_stateField.value+="|"+_fqstates.join(",");}}
function _handleFQStateChange(fqstate){var i,len,moduleName,moduleObj,modules,states,tokens,currentState;if(!fqstate){for(moduleName in _modules){if(YAHOO.lang.hasOwnProperty(_modules,moduleName)){moduleObj=_modules[moduleName];moduleObj.currentState=moduleObj.initialState;moduleObj.onStateChange(unescape(moduleObj.currentState));}}
return;}
modules=[];states=fqstate.split("&");for(i=0,len=states.length;i<len;i++){tokens=states[i].split("=");if(tokens.length===2){moduleName=tokens[0];currentState=tokens[1];modules[moduleName]=currentState;}}
for(moduleName in _modules){if(YAHOO.lang.hasOwnProperty(_modules,moduleName)){moduleObj=_modules[moduleName];currentState=modules[moduleName];if(!currentState||moduleObj.currentState!==currentState){moduleObj.currentState=currentState||moduleObj.initialState;moduleObj.onStateChange(unescape(moduleObj.currentState));}}}}
function _updateIFrame(fqstate){var html,doc;html='<html><body><div id="state">'+fqstate+'</div></body></html>';try{doc=_histFrame.contentWindow.document;doc.open();doc.write(html);doc.close();return true;}catch(e){return false;}}
function _checkIframeLoaded(){var doc,elem,fqstate,hash;if(!_histFrame.contentWindow||!_histFrame.contentWindow.document){setTimeout(_checkIframeLoaded,10);return;}
doc=_histFrame.contentWindow.document;elem=doc.getElementById("state");fqstate=elem?elem.innerText:null;hash=_getHash();setInterval(function(){var newfqstate,states,moduleName,moduleObj,newHash,historyLength;doc=_histFrame.contentWindow.document;elem=doc.getElementById("state");newfqstate=elem?elem.innerText:null;newHash=_getHash();if(newfqstate!==fqstate){fqstate=newfqstate;_handleFQStateChange(fqstate);if(!fqstate){states=[];for(moduleName in _modules){if(YAHOO.lang.hasOwnProperty(_modules,moduleName)){moduleObj=_modules[moduleName];states.push(moduleName+"="+moduleObj.initialState);}}
newHash=states.join("&");}else{newHash=fqstate;}
top.location.hash=newHash.substring(5);hash=newHash;_storeStates();}else if(newHash!==hash){hash=newHash;_updateIFrame(newHash);}},50);_initialized=true;YAHOO.util.History.onLoadEvent.fire();}
function _initialize(){var i,len,parts,tokens,moduleName,moduleObj,initialStates,initialState,currentStates,currentState,counter,hash;parts=_stateField.value.split("|");if(parts.length>1){initialStates=parts[0].split("&");for(i=0,len=initialStates.length;i<len;i++){tokens=initialStates[i].split("=");if(tokens.length===2){moduleName=tokens[0];initialState=tokens[1];moduleObj=_modules[moduleName];if(moduleObj){moduleObj.initialState=initialState;}}}
currentStates=parts[1].split("&");for(i=0,len=currentStates.length;i<len;i++){tokens=currentStates[i].split("=");if(tokens.length>=2){moduleName=tokens[0];currentState=tokens[1];moduleObj=_modules[moduleName];if(moduleObj){moduleObj.currentState=currentState;}}}}
if(parts.length>2){_fqstates=parts[2].split(",");}
if(YAHOO.env.ua.ie){if(typeof document.documentMode==="undefined"||document.documentMode<8){_checkIframeLoaded();}else{YAHOO.util.Event.on(top,"hashchange",function(){var hash=_getHash();_handleFQStateChange(hash);_storeStates();});_initialized=true;YAHOO.util.History.onLoadEvent.fire();}}else{counter=history.length;hash=_getHash();setInterval(function(){var state,newHash,newCounter;newHash=_getHash();newCounter=history.length;if(newHash!==hash){hash=newHash;counter=newCounter;_handleFQStateChange(hash);_storeStates();}else if(newCounter!==counter&&YAHOO.env.ua.webkit){hash=newHash;counter=newCounter;state=_fqstates[counter-1];_handleFQStateChange(state);_storeStates();}},50);_initialized=true;YAHOO.util.History.onLoadEvent.fire();}}
return{onLoadEvent:new YAHOO.util.CustomEvent("onLoad"),onReady:function(fn,obj,override){if(_initialized){setTimeout(function(){var ctx=window;if(override){if(override===true){ctx=obj;}else{ctx=override;}}
fn.call(ctx,"onLoad",[],obj);},0);}else{YAHOO.util.History.onLoadEvent.subscribe(fn,obj,override);}},register:function(module,initialState,onStateChange,obj,override){var scope,wrappedFn;if(typeof module!=="string"||YAHOO.lang.trim(module)===""||typeof initialState!=="string"||typeof onStateChange!=="function"){throw new Error("Missing or invalid argument");}
if(_modules[module]){return;}
if(_initialized){throw new Error("All modules must be registered before calling YAHOO.util.History.initialize");}
module=escape(module);initialState=escape(initialState);scope=null;if(override===true){scope=obj;}else{scope=override;}
wrappedFn=function(state){return onStateChange.call(scope,state,obj);};_modules[module]={name:module,initialState:initialState,currentState:initialState,onStateChange:wrappedFn};},initialize:function(stateField,histFrame){if(_initialized){return;}
if(YAHOO.env.ua.opera&&typeof history.navigationMode!=="undefined"){history.navigationMode="compatible";}
if(typeof stateField==="string"){stateField=document.getElementById(stateField);}
if(!stateField||stateField.tagName.toUpperCase()!=="TEXTAREA"&&(stateField.tagName.toUpperCase()!=="INPUT"||stateField.type!=="hidden"&&stateField.type!=="text")){throw new Error("Missing or invalid argument");}
_stateField=stateField;if(YAHOO.env.ua.ie&&(typeof document.documentMode==="undefined"||document.documentMode<8)){if(typeof histFrame==="string"){histFrame=document.getElementById(histFrame);}
if(!histFrame||histFrame.tagName.toUpperCase()!=="IFRAME"){throw new Error("Missing or invalid argument");}
_histFrame=histFrame;}
YAHOO.util.Event.onDOMReady(_initialize);},navigate:function(module,state){var states;if(typeof module!=="string"||typeof state!=="string"){throw new Error("Missing or invalid argument");}
states={};states[module]=state;return YAHOO.util.History.multiNavigate(states);},multiNavigate:function(states){var currentStates,moduleName,moduleObj,currentState,fqstate;if(typeof states!=="object"){throw new Error("Missing or invalid argument");}
if(!_initialized){throw new Error("The Browser History Manager is not initialized");}
for(moduleName in states){if(!_modules[moduleName]){throw new Error("The following module has not been registered: "+moduleName);}}
currentStates=[];for(moduleName in _modules){if(YAHOO.lang.hasOwnProperty(_modules,moduleName)){moduleObj=_modules[moduleName];if(YAHOO.lang.hasOwnProperty(states,moduleName)){currentState=states[unescape(moduleName)];}else{currentState=unescape(moduleObj.currentState);}
moduleName=escape(moduleName);currentState=escape(currentState);currentStates.push(moduleName+"="+currentState);}}
fqstate=currentStates.join("&");if(YAHOO.env.ua.ie&&(typeof document.documentMode==="undefined"||document.documentMode<8)){return _updateIFrame(fqstate);}else{top.location.hash=fqstate.substring(5);if(YAHOO.env.ua.webkit){_fqstates[history.length]=fqstate;_storeStates();}
return true;}},getCurrentState:function(module){var moduleObj;if(typeof module!=="string"){throw new Error("Missing or invalid argument");}
if(!_initialized){throw new Error("The Browser History Manager is not initialized");}
moduleObj=_modules[module];if(!moduleObj){throw new Error("No such registered module: "+module);}
return unescape(moduleObj.currentState);},getBookmarkedState:function(module){var i,len,idx,hash,states,tokens,moduleName;if(typeof module!=="string"){throw new Error("Missing or invalid argument");}
idx=top.location.href.indexOf("#");if(idx>=0){hash="page="+top.location.href.substr(idx+1);states=hash.split("&");for(i=0,len=states.length;i<len;i++){tokens=states[i].split("=");if(tokens.length===2){moduleName=tokens[0];if(moduleName===module){return unescape(tokens[1]);}}}}
return null;},};})();YAHOO.register("history",YAHOO.util.History,{version:"2.7.0",build:"1799"});
var fileContentArray=[];var fileTitleArray=[];fileContentArray['home']="This is the body of the home page.<br/> <img src='/jonathankoff.com/images/kitten.jpg' /> <img src='/jonathankoff.com/images/kitten.JPG' /> ";fileTitleArray['home']="Home";fileContentArray['about']="This is the body of the about page. ";fileTitleArray['about']="About Jonathan Koff";fileContentArray['portfolio']="This is the body of the portfolio page. ";fileTitleArray['portfolio']="Portfolio";fileContentArray['contact']="This is the body of the contact page. ";fileTitleArray['contact']="Contact Information";function preloader(){for(txt in fileContentArray){var match=fileContentArray[txt].match(/<img src=['"]?([^='"<>\b]*)['"]?\b/ig);imgObj=new Image();for(img in match){var src=match[img].substring(match[img].indexOf("'")+1);imgObj.src=src;}}}
function setIdContent(id,file){if(!fileTitleArray[file])file="home";var obj=document.getElementById(id);if(obj)
obj.innerHTML=fileContentArray[file];document.title=fileTitleArray[file];}
function initNav(){var anchors,i,len,anchor,href,section,currentSection;anchors=document.getElementById("nav").getElementsByTagName("a");for(i=0,len=anchors.length;i<len;i++){anchor=anchors[i];YAHOO.util.Event.addListener(anchor,"click",function(evt){href=this.getAttribute("href");patharr=href.split('/');section=patharr[patharr.length-2]||"home";try{YAHOO.util.History.navigate("page",section);}catch(e){setIdContent("content",section);}
YAHOO.util.Event.preventDefault(evt);});}
currentSection=YAHOO.util.History.getCurrentState("page");setIdContent("content",currentSection);}
var bookmarkedState=YAHOO.util.History.getBookmarkedState("page");var href=""+window.location;var patharr=href.split('/');var section=patharr[patharr.length-2]||"home";var querySection=section;if(!fileContentArray[querySection])
querySection="home";var initialState=bookmarkedState||querySection||"home";YAHOO.util.History.register("page",initialState,function(state){if(state)setIdContent("content",state);});YAHOO.util.History.onReady(function(){initNav();preloader();});try{YAHOO.util.History.initialize("yui-history-field","yui-history-iframe");}catch(e){setIdContent("content","home");}
--></script>
	</body>
</html>

